Add your ActiveRecord models here.

You can create them by being in the application root directory and running:

`rake generate:model NAME=User`
